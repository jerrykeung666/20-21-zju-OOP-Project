#include "user.h"

User::User(QObject *parent) : Player(parent)
{
    isPerson = true;
}

void User::startCallLord()
{

}

void User::startPlayHand()
{

}
